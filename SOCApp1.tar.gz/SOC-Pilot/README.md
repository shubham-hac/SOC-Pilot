# SOC Pilot

A working hackathon MVP for investigating security alerts against the supplied SOC playbooks and CVE dataset. React + TypeScript, FastAPI, persistent Chroma, BM25, and SQLite.

## Run locally

Requires Python 3.11+ and Node.js 20.19+ (tested with Python 3.13).

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirement.txt
cd frontend
npm install
npm run build
cd ..
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000. API documentation: http://127.0.0.1:8000/docs.

For reproducible JavaScript dependencies, use `pnpm install --frozen-lockfile` and `pnpm build` instead of npm; the pnpm lockfile is committed. Development UI: `npm run dev` in `frontend/` (port 5173), with the API on port 8000. Build before starting FastAPI to serve the production UI from the same process.

The index is created from `dataset/` at startup. `.runtime/` holds the index and incidents. No API key or model download is needed. Set `SOC_STORAGE=/path/to/storage` to change the state directory.

## Try the demo

1. Analyze the phishing sample. Review extracted indicators and the four containment steps. Open a source citation to see exact lines and the pinned version.
2. Analyze ransomware. Record approval for an isolation/reset step, then mark it complete. Add an analyst note in the Timeline tab.
3. Generate an incident ticket and download Markdown or JSON. Completed and pending actions are separate; root cause stays undetermined.
4. Analyze the credential-stuffing sample or existing NGINX injection log. The warning identifies instruction-like text without lowering severity.
5. Analyze public S3: the app reports missing coverage. Analyze the NGINX CVE sample: advisory evidence is shown without an invented containment runbook.
6. Reopen incidents from history. Reindex after editing local knowledge; saved incidents retain their original source snapshots.

## What is implemented

- JSON object/array and NGINX intake, file upload, five new JSON samples plus two existing logs.
- Deterministic IoC extraction and rule classification, basic secret redaction, injection warning.
- Step-level SOP ingestion, CVE 5.x normalization, persistent Chroma vector index, BM25/RRF retrieval.
- Exact extractive checklist, phase filtering, source viewer, conservative approval acknowledgments, progress tracking.
- Candidate CVE cards with CNA CVSS, source references, and explicit exposure uncertainty.
- Persistent incidents, transactional timeline events, Markdown/JSON incident tickets.
- Knowledge coverage, reindexing, missing-playbook refusal, regression tests.

## Honest MVP boundaries

This release implements the deterministic fallback described in `Architecture.md`. The 384-dimensional vectors are hashed lexical features, **not pretrained semantic embeddings**. There is no LLM call, cross-encoder reranker, copilot chat, or incident correlation yet. Hybrid retrieval ranks source chunks; the matched playbook's complete numbered investigation/containment/eradication/recovery sequence is then preserved.

The SSE endpoint is available with `?stream=true`, but events are emitted after analysis; the UI uses JSON. Live progressive generation is not implemented. Root cause is not inferred. CVE data is the supplied local snapshot; product/version applicability and current advisory status require investigation.

The repository has phishing, ransomware, brute-force, malware, and suspicious-login SOPs. Credential stuffing is covered by brute force; DDoS and S3 SOPs are missing. Supplied procedures have not been independently approved by an organization.

Run locally for a single analyst. There is no authentication, role separation, immutable audit log, or comprehensive PII masking. Approval buttons record acknowledgments only. No response actions are executed, and no tickets are sent externally.

## Tests

```bash
python -m pytest backend/tests -q
cd frontend
npm run build
```

`scripts/smoke.mjs` exercises the built app with Playwright (install Playwright separately for development). It covers analysis, citations, approval, completion, timeline notes, ticket downloads, history, gap behavior, and mobile overflow. Set `PLAYWRIGHT_MODULE` to an existing Playwright module path if it is not installed locally. Screenshots are written under `.runtime/`.

## API

| Endpoint | Purpose |
|---|---|
| `GET /v1/health` | Index counts, generation/embedding modes |
| `GET /v1/samples` | Synthetic JSON examples and supplied logs |
| `POST /v1/alerts/parse` | `{ "raw": "..." }` parser-only result |
| `POST /v1/alerts/analyze` | Parse, retrieve, verify, save incident |
| `GET /v1/incidents` | Latest 50 incidents |
| `GET /v1/incidents/{id}` | Saved state and source snapshots |
| `POST /v1/incidents/{id}/events` | `type`: approve, complete, reopen, note; optional `step_id` / `note` |
| `POST /v1/incidents/{id}/ticket` | Ticket JSON, Markdown, and incident snapshot |
| `POST /v1/knowledge/ingest` | Reindex dataset |
| `GET /v1/knowledge/gaps` | Coverage and provenance |

See `PRD.md` for requirements/status, `skills.md` for contributor conventions, `requirement.txt` for Python dependencies, and `Architecture.md` for the broader roadmap.

For setup details, endpoint examples, API-key guidance, and an application walkthrough, see [`APPLICATION_GUIDE.md`](APPLICATION_GUIDE.md).
