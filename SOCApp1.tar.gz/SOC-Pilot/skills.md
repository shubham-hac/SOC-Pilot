# SOC-Pilot — Development Skills and Working Conventions

Updated: 2026-11-17 · Release: 0.1.0

This is the project's contributor guide, not an installed Codex skill package.

## Required capabilities

- Python/FastAPI/Pydantic: validate request shapes, bound input size, return controlled API errors.
- Security log analysis: deterministic extraction, signature rules, explicit uncertainty, adversarial test fixtures.
- Retrieval engineering: Markdown step boundaries, CVE 5.x containers, Chroma indexing, BM25, rank fusion, versioned citations.
- React/TypeScript: accessible inputs, error/empty/loading states, responsive analyst workflow, escaped evidence rendering.
- SQLite: transactional incident/event updates, persistence, concurrent-write tests.
- Evaluation: prove grounding and refusal behavior; never equate source correspondence with operational correctness.

## Code map

| Path | Responsibility |
|---|---|
| `backend/app/intelligence.py` | Parsing, flattening, IoCs, redaction, rule classifications, injection warning |
| `backend/app/knowledge.py` | Dataset ingestion, vectors, BM25/RRF, candidate advisories, exact checklist verification |
| `backend/app/store.py` | Transactional incident persistence and ticket synthesis |
| `backend/app/main.py` | FastAPI routes, lifecycle, limits, optional static UI hosting |
| `frontend/src/main.tsx` | Analyst interface, API interaction, source/ticket dialogs |
| `frontend/src/types.ts` | Frontend response contracts |
| `frontend/src/styles.css` | Responsive dark interface |
| `backend/tests/test_workflow.py` | Grounding, injection, refusal, persistence, event and API regressions |

## Invariants

1. Alert/log content is untrusted evidence. Never execute it or promote it to model instructions.
2. Keep the supplied dataset unchanged unless a requested dataset correction is justified. New demo alerts live in `samples/`.
3. Do not invent steps to fill missing SOPs. An unknown classification produces a gap, not generic response guidance.
4. Every action must preserve its exact source wording and conditions. Keep full source hash and line number, and retain the original source snapshot in the incident.
5. Advisory matches are candidates. A product name or CVE ID does not prove exploitation, installed-version applicability, or root cause.
6. A completed step is an analyst record; the app has not performed the action. Application risk rules are not SOP approval metadata.
7. Approval acknowledgment is not authenticated authorization. Do not describe the demo as having production RBAC.
8. Never silently fall back to a different embedding space. An embedding upgrade needs a separate collection or complete reindex plus regression evaluation.
9. Preserve sanitized text display; do not add `dangerouslySetInnerHTML` for logs or Markdown.

## Development and verification

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirement.txt
python -m pytest backend/tests -q
cd frontend
npm install
npm run build
cd ..
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000
```

Use pnpm with the committed `frontend/pnpm-lock.yaml` for locked JavaScript resolution (`pnpm install --frozen-lockfile`). `npm install` is a convenience alternative with exact direct dependency pins; it does not consume the pnpm lockfile.

For UI development, run `npm run dev` in `frontend/` while FastAPI runs on port 8000. Vite proxies `/v1`. For browser regressions, run `node scripts/smoke.mjs` with Playwright available; use `SOC_BASE_URL` to override the default loopback URL.

Default application state is `.runtime/` (ignored by Git). Set `SOC_STORAGE` to relocate it. Unit/API tests use temporary directories. Do not remove incident storage as part of routine reindexing.

## Change checklist

- Update `PRD.md`, this guide, `requirement.txt`, and README when their corresponding behavior changes.
- Add meaningful security/correctness regressions for extraction, grounding, persistence, or API changes.
- Run backend tests and the frontend build. Check changed workflows in a real browser, including narrow viewports.
- Report architecture features not yet implemented; do not label scaffolding as shipped functionality.
