# SOC-Pilot — Product Requirements

Version: 0.1.0 · Updated: 2026-11-17

## Product outcome

Reduce the time SOC analysts spend finding incident response procedures during an alert. Turn JSON alerts and NGINX logs into extracted indicators, a source-backed response checklist, relevant local CVE intelligence, and a downloadable incident ticket. Analysts perform all containment actions themselves.

The intended architecture is in `Architecture.md`. This PRD records the implemented slice and explicitly separates it from the full architectural roadmap.

## Users and workflow

SOC L1/L2 analysts paste an alert, upload a file, or select a sample. They inspect rule-based classification and IoCs, review exact SOP citations, record approval acknowledgments and completed steps, add timeline notes, and generate a Markdown or JSON ticket. A knowledge view exposes coverage gaps; incident history restores previous investigations.

## Dataset inventory

- Five existing playbooks: phishing, ransomware, brute force, malware, suspicious login.
- Credential stuffing maps to the brute-force playbook, whose purpose explicitly covers it.
- Five existing CVE 5.x JSON advisories: three NGINX-family and two PHP-family records.
- Two existing NGINX log fixtures, including attacker-controlled prompt-injection text.
- Five added synthetic JSON examples under `samples/`: phishing, ransomware, credential stuffing with injection, public S3 coverage gap, and an explicit NGINX CVE candidate.
- DDoS and public S3 playbooks are absent. Do not fabricate or silently label newly written procedures as approved.
- Supplied repository procedures are not independently established as organizationally approved. CVE data is a local snapshot, not verified live intelligence.

## Functional requirements and status

| ID | Requirement | Current behavior |
|---|---|---|
| FR-01 | Index playbooks and CVEs | Implemented: persistent Chroma, structure-aware numbered SOP chunks, full content hashes, idempotent reindex, stale chunk removal |
| FR-02 | Parse alerts deterministically | Implemented: JSON objects/arrays/text and NGINX logs; validated IPv4/IPv6, URLs, emails, hashes, CVE IDs, selected domains and S3 resource identifiers |
| FR-03 | Classify alert behavior | Implemented: explicit signature rules with evidence and MITRE labels; confidence is a documented heuristic; unknown alerts abstain |
| FR-04 | Retrieve relevant knowledge | Implemented baseline: 384-dimensional hashed word/ngram vectors + BM25 and reciprocal-rank fusion; classified playbook filter preserves complete ordered procedure |
| FR-05 | Generate grounded checklist | Implemented: deterministic extractive fallback, verbatim actions, exact line verification, pinned source snapshots and content hashes; phase filters |
| FR-06 | Surface vulnerability intelligence | Implemented: explicit CVE-ID and exact affected-product candidates, CNA CVSS if present, source references, no implied confirmed exposure |
| FR-07 | Track analyst work | Implemented: SQLite persistence, progress, approval acknowledgments for conservatively identified high-impact actions, notes, event timeline |
| FR-08 | Generate incident ticket | Implemented: one-click preview/download of Markdown and JSON, separate completed/pending actions, timeline, citations, indicators, root cause explicitly undetermined |
| FR-09 | Show knowledge gaps | Implemented: DDoS/S3 coverage view, unknown-classification refusal, missing local CVE messages |
| FR-10 | Streaming | API emits typed SSE when requested; analysis currently completes before event emission. UI uses JSON response; true progressive retrieval/generation remains planned |

## Acceptance criteria

1. Each golden sample maps to its expected class and supplied SOP, or produces an explicit coverage gap.
2. Every visible step equals source text at a valid line in its pinned document snapshot; preserve conditional clauses and source order.
3. Unknown, DDoS, and public S3 scenarios never receive an unrelated containment procedure.
4. Supplied injection log yields brute-force classification and high severity, with an injection warning.
5. High-impact steps cannot be completed through the API before an approval acknowledgment is recorded.
6. Completed steps and notes survive reloads; concurrent event writes do not overwrite each other.
7. Tickets never present pending actions as performed or a CVE candidate as confirmed root cause.
8. Malformed JSON, unsupported formats, and requests over 256 KB receive controlled errors. File upload limit is 240 KB.
9. React TypeScript production build and backend regression suite pass; browser workflow validates sample analysis, citation viewing, approval/completion, notes, ticket download, history, and narrow layout.

## Nonfunctional requirements

- Local-only runtime: no external LLM calls or embedding model downloads in this release. Dependencies require an initial install.
- Backend defaults to loopback; this is a single-analyst hackathon application, without authentication, tenant isolation, or tamper-proof audit storage.
- No auto-execution, shell execution, or ITSM publishing of response actions.
- Known key/token patterns are redacted before persistence; this is not a comprehensive secret or PII detector.
- UI escapes alert/source text through React. URLs in evidence reference only HTTPS advisory links from the dataset.
- First useful result target: under three seconds for small demo alerts after index warmup. Production p95 and large-corpus performance are not established.
- Dataset provenance and source versions must remain visible.

## Deferred roadmap

P0 follow-up: semantic BGE embeddings, measured retrieval ranking, cross-encoder reranking, optional schema-constrained LLM provider and evidence verifier, true progressive SSE UI, calibrated behavior classification. Current vector mode is lexical and must not be described as semantic understanding.

P1: analyst-reviewed DDoS/S3 procedures, authenticated role-separated approvals, asset/version applicability matching, richer normalized event timestamps and multi-label procedure merging, evaluation dashboard, incident correlation.

P2: grounded incident chat, PDF export, live CVE refresh with provenance, ITSM integrations, production RBAC and immutable audit export.

## Maintenance rule

Update this PRD when observable behavior, requirements, or scope changes. Update `skills.md` when implementation conventions or operational commands change. Update `requirement.txt` whenever a Python dependency changes. Keep the README and tests aligned with actual behavior.

The application walkthrough and current API-key guidance are maintained in `APPLICATION_GUIDE.md`.

## Verification record — 2026-11-17

- 16 backend tests passed against the supplied dataset and synthetic alerts.
- TypeScript check and Vite production build passed.
- Headless Chrome workflow passed: analysis, exact source highlighting, approval, completion, notes, Markdown download, saved history, missing-SOP refusal, and 390px mobile overflow check.
- Desktop and mobile screenshots visually inspected; no browser JavaScript errors in the tested workflow.
- This validates the demo scenarios, not the architecture's 95% production classification or semantic-retrieval targets.
