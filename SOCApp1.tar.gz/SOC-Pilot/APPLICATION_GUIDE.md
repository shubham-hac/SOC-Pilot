# SOC-Pilot Application Guide

Updated: 2026-11-17

## Where do I put my API key?

You do not need an API key for the current version. The app does not call OpenAI or another hosted language model, and there is no provider integration or `OPENAI_API_KEY` setting in the code today. Alert parsing, retrieval, checklist assembly, and ticket creation run locally.

Do not paste a key into an alert, the browser, a source file, or `frontend/`. If a hosted LLM is added later, configure its key on the **backend only**, for example in a local `.env` file read by the backend and excluded from Git. Never expose provider secrets as `VITE_*` variables; Vite embeds those values in browser code. No such variable is read by this release, so creating `.env` now will have no effect.

## Where are the API endpoints?

When the app is running on this computer, the API base URL is:

```text
http://127.0.0.1:8000/v1
```

FastAPI's interactive endpoint reference is at [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs). The API implementation is [backend/app/main.py](/home/labuser/Desktop/SOC-Pilot/backend/app/main.py). In development, the React app runs on port 5173 and Vite forwards `/v1` requests to port 8000; in production the same FastAPI process can serve the built frontend and API.

| Method | Local path | Purpose |
|---|---|---|
| GET | `/v1/health` | Readiness and indexed document counts |
| GET | `/v1/samples` | Load example alerts for the UI |
| POST | `/v1/alerts/parse` | Parse IoCs and classification without saving an incident |
| POST | `/v1/alerts/analyze` | Analyze an alert and save a cited checklist; add `?stream=true` for the current SSE response |
| GET | `/v1/incidents` | List recent incidents |
| GET | `/v1/incidents/{incident_id}` | Read a saved incident |
| POST | `/v1/incidents/{incident_id}/events` | Record approval, completion, reopen, or analyst note |
| POST | `/v1/incidents/{incident_id}/ticket` | Build an incident ticket |
| POST | `/v1/knowledge/ingest` | Reindex local playbooks and CVE JSON |
| GET | `/v1/knowledge/gaps` | Inspect unsupported playbook categories |

For example, with the server running:

```bash
curl http://127.0.0.1:8000/v1/health
curl -X POST http://127.0.0.1:8000/v1/alerts/analyze \
  -H 'Content-Type: application/json' \
  -d '{"raw":{"rule_name":"Phishing alert","severity":"high"}}'
```

An incident event request looks like:

```json
{"type":"note","note":"Analyst confirmed the affected mailbox."}
```

For an approval or step completion, add the step's `step_id`, for example `{"type":"approve","step_id":"..."}`. These endpoints record analyst actions; the app does not perform containment itself.

## Run the app

From the repository root, install the packages described in [README.md](/home/labuser/Desktop/SOC-Pilot/README.md), build the frontend, then start:

```bash
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000
```

Open [http://127.0.0.1:8000](http://127.0.0.1:8000) for the application or `/docs` for the endpoint explorer. The running local demo endpoint is on this machine only; it is not a public internet URL.

## How the application works

1. **Alert intake:** paste JSON or NGINX log text, upload a local file, or choose a sample in the React UI.
2. **Parse and classify:** FastAPI validates the input, redacts a few common secret patterns, extracts indicators such as IPs, URLs, hashes and CVE IDs, then applies deterministic signature rules. Classification confidence is a heuristic, not a calibrated probability.
3. **Retrieve knowledge:** the backend indexes numbered actions from the Markdown playbooks and the supplied CVE JSON in a persistent local Chroma collection. Hashed word/ngram vectors and BM25 are combined for lexical retrieval; these are not pretrained semantic embeddings.
4. **Build a grounded checklist:** for a recognized attack category, it presents the matching playbook's original, ordered investigation and response actions. It checks the quoted source line and keeps the document snapshot and content hash with the incident. If the category is unknown or unsupported, it reports a gap rather than inventing a procedure.
5. **Track analyst work:** checklist progress, approval acknowledgments, notes and event times are stored in SQLite under `.runtime/` by default. An acknowledgment records an analyst's click; it is not authenticated role-based approval.
6. **Make the ticket:** the ticket includes indicators, cited completed and pending actions, the activity timeline, knowledge gaps and relevant CVE candidates. Root cause stays undetermined unless an analyst investigates it; an advisory match alone does not prove that a host is vulnerable or compromised.

## Main folders and files

| Path | Contains |
|---|---|
| `frontend/` | React/TypeScript analyst interface and Vite configuration |
| `backend/app/` | FastAPI routes, alert parsing, retrieval, persistence and tickets |
| `dataset/` | Supplied Markdown runbooks and CVE advisory files |
| `samples/` | Synthetic JSON examples for phishing, ransomware, credential stuffing, S3 and CVE scenarios |
| `testdata/` | Supplied NGINX logs, including a prompt-injection test |
| `.runtime/` | Generated Chroma index, SQLite incident database and local smoke-test screenshots; ignored by Git |
| `Architecture.md` | Broader target architecture and future roadmap |
| `PRD.md` | Requirements and implemented/deferred status |

## Current limitations

There is no API key to configure because hosted LLM generation is not integrated. The current procedure generator is extractive and deterministic. The local CVE files are a static dataset, not a live threat feed. DDoS and public S3 procedures are absent from the supplied playbooks, so the app identifies those coverage gaps. The demo has no authentication, production access controls or external ticketing connection.
