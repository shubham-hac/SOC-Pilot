import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4


def now():
    return datetime.now(timezone.utc).isoformat()


class Store:
    def __init__(self, path: Path):
        self.path = path
        with self.connect() as db:
            db.execute(
                "CREATE TABLE IF NOT EXISTS incidents (id TEXT PRIMARY KEY, created_at TEXT, body TEXT NOT NULL)"
            )

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    def create(self, incident):
        incident.update(id=f"INC-{uuid4().hex[:10].upper()}", created_at=now())
        incident["timeline"] = [
            {
                "at": incident["created_at"],
                "type": "analyzed",
                "detail": "Alert analyzed; source-backed response checklist created.",
            }
        ]
        with self.connect() as db:
            db.execute(
                "INSERT INTO incidents VALUES (?, ?, ?)",
                (incident["id"], incident["created_at"], json.dumps(incident)),
            )
        return incident

    def get(self, incident_id):
        with self.connect() as db:
            row = db.execute(
                "SELECT body FROM incidents WHERE id=?", (incident_id,)
            ).fetchone()
        if not row:
            raise KeyError(incident_id)
        return json.loads(row["body"])

    def list(self):
        with self.connect() as db:
            rows = db.execute(
                "SELECT body FROM incidents ORDER BY created_at DESC LIMIT 50"
            ).fetchall()
        return [
            {
                "id": i["id"],
                "created_at": i["created_at"],
                "classification": i["parsed"]["classification"]["primary"],
                "severity": i["parsed"]["severity"],
            }
            for i in (json.loads(r["body"]) for r in rows)
        ]

    def event(self, incident_id, event):
        # Serialize read-modify-write so simultaneous notes/checkboxes cannot overwrite each other.
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute(
                "SELECT body FROM incidents WHERE id=?", (incident_id,)
            ).fetchone()
            if not row:
                raise KeyError(incident_id)
            incident = json.loads(row["body"])
            kind = event["type"]
            if kind in ("complete", "reopen", "approve"):
                step = next(
                    (
                        s
                        for s in incident["checklist"]
                        if s["id"] == event.get("step_id")
                    ),
                    None,
                )
                if not step:
                    raise ValueError("Unknown checklist step.")
                if (
                    kind == "complete"
                    and step["requires_approval"]
                    and not step["approved"]
                ):
                    raise ValueError(
                        "Record analyst approval before marking this high-impact step complete."
                    )
                if kind == "approve":
                    step["approved"] = True
                else:
                    step["status"] = "done" if kind == "complete" else "pending"
                detail = f'{kind}: {step["action"]}'
            elif kind == "note":
                detail = event.get("note", "").strip()
                if not detail:
                    raise ValueError("Note cannot be empty.")
            elif kind == "ticket_generated":
                detail = "Incident ticket generated from current evidence and recorded actions."
            else:
                raise ValueError("Unsupported event type.")
            incident["timeline"].append({"at": now(), "type": kind, "detail": detail})
            db.execute(
                "UPDATE incidents SET body=? WHERE id=?",
                (json.dumps(incident), incident_id),
            )
        return incident


def ticket(incident):
    parsed = incident["parsed"]
    done = [s for s in incident["checklist"] if s["status"] == "done"]
    pending = [s for s in incident["checklist"] if s["status"] != "done"]
    lines = [
        f'# {incident["id"]} — {parsed["classification"]["primary"].replace("_", " ").title()}',
        "",
        f'Severity: {parsed["severity"].upper()}',
        f'Created (UTC): {incident["created_at"]}',
        f'Alert-reported time (unverified): {parsed["observed_at"] or "Not supplied"}',
        "",
        "## Root cause",
        "Undetermined. Classification is a triage hypothesis, not a confirmed root cause.",
        "",
        "## Indicators (defanged)",
        *[f'- {i["type"]}: {i["display"]}' for i in parsed["iocs"]],
        "",
        "## Actions recorded complete by analyst",
    ]

    def render_step(s):
        c = s["citation"]
        return f'- {s["action"]} ({c["source"]}:L{c["line_start"]}, SHA256 {c["version"][:12]})'

    lines.extend([render_step(s) for s in done] or ["None recorded."])
    lines.extend(
        [
            "",
            "## Pending actions",
            *[render_step(s) for s in pending],
            "",
            "## Knowledge gaps",
            *incident["gaps"],
            "",
            "## CVE candidates (exposure unconfirmed)",
            *[f'- {c["id"]}: {c["match_reason"]}' for c in incident["cves"]],
            "",
            "## Timeline (UTC)",
            *[f'- {e["at"]} — {e["detail"]}' for e in incident["timeline"]],
            "",
            "Generated in local demo mode. Approval entries are analyst acknowledgments, not authenticated authorization.",
        ]
    )
    return {
        "incident_id": incident["id"],
        "markdown": "\n".join(lines),
        "root_cause": "Undetermined",
        "completed_actions": len(done),
        "pending_actions": len(pending),
        "incident": incident,
    }
