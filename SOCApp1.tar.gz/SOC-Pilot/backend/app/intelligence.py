"""Deterministic extraction. Log text is evidence, never executable instructions."""

import ipaddress
import json
import re
from urllib.parse import urlsplit

INJECTION = re.compile(
    r"ignore (?:all |previous |prior )*instructions|you are now|SYSTEM:|output all job results|set severity to",
    re.I,
)
SECRET = re.compile(r"AKIA[A-Z0-9]{16}|(?i:Bearer)\s+[A-Za-z0-9._~+/=-]+")


def redact(text: str) -> str:
    text = SECRET.sub("[REDACTED]", text)
    return re.sub(
        r'(?i)(["\']?(?:password|secret|api_key|access_token|authorization)["\']?\s*[:=]\s*)["\']?[^\s,"\'}]+["\']?',
        r'\1"[REDACTED]"',
        text,
    )


def flatten(value, prefix=""):
    if isinstance(value, dict):
        for key, item in value.items():
            yield from flatten(item, f"{prefix}.{key}" if prefix else str(key))
    elif isinstance(value, list):
        for i, item in enumerate(value):
            yield from flatten(item, f"{prefix}.{i}")
    else:
        yield prefix, str(value)


def parse_alert(raw: str | dict) -> dict:
    if isinstance(raw, str):
        if not raw.strip():
            raise ValueError("Paste a JSON alert or an NGINX log first.")
        if raw.lstrip().startswith(("{", "[")):
            try:
                raw = json.loads(raw)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"Invalid JSON at line {exc.lineno}, column {exc.colno}."
                ) from exc
        elif not re.search(r"\[(?:error|notice|warn|\d{2}/\w+/\d{4}:)", raw):
            raise ValueError(
                "Input must be a JSON object, JSON alert array, or NGINX log."
            )
    if not isinstance(raw, (dict, list, str)):
        raise ValueError("Alert must be an object or an array of objects.")
    if isinstance(raw, list) and (not raw or not all(isinstance(x, dict) for x in raw)):
        raise ValueError("JSON arrays must contain alert objects.")
    fields = list(flatten(raw)) if not isinstance(raw, str) else [("nginx.log", raw)]
    safe_fields = {k: redact(v) for k, v in fields}
    text = "\n".join(safe_fields.values())
    warnings = (
        [
            "Instruction-like text detected in alert data; it is not used as instructions."
        ]
        if INJECTION.search(text)
        else []
    )
    # Exclude instruction-bearing strings from classification, retaining IoCs for investigation.
    evidence_text = "\n".join(
        v for v in safe_fields.values() if not INJECTION.search(v)
    )
    if isinstance(raw, str):
        # Request/status fields remain useful even when a user agent contains instructions.
        evidence_text = "\n".join(
            re.sub(
                r'"[^"\n]*(?:ignore previous|you are now|SYSTEM:)[^\n]*',
                "",
                line,
                flags=re.I,
            )
            for line in text.splitlines()
        )
    lower = evidence_text.lower()
    rules = [
        (
            "ransomware",
            [
                "ransomware",
                "vssadmin delete shadows",
                "mass encryption",
                "files encrypted",
            ],
            ["T1486", "T1490"],
            "critical",
        ),
        (
            "phishing",
            [
                "phishing",
                "credential-harvesting",
                "malicious email",
                "suspicious email",
            ],
            ["T1566"],
            "high",
        ),
        (
            "credential_stuffing",
            ["credential stuffing", "credential_stuffing"],
            ["T1110.004"],
            "high",
        ),
        (
            "brute_force",
            [
                "brute force",
                "brute_force",
                "password mismatch",
                "password spraying",
                "failed logins",
            ],
            ["T1110"],
            "high",
        ),
        (
            "public_s3",
            ["allusers", "public s3", "public_s3", "public-read"],
            ["T1530"],
            "high",
        ),
        ("ddos", ["ddos", "syn flood", "udp flood"], ["T1498"], "high"),
        ("malware", ["malware", "trojan", "dll sideloading"], ["T1204"], "high"),
        (
            "suspicious_login",
            ["impossible travel", "suspicious login", "suspicious_login"],
            ["T1078"],
            "high",
        ),
    ]
    matches = []
    for label, signatures, mitre, severity in rules:
        hits = [s for s in signatures if s in lower]
        if (
            label == "brute_force"
            and len(re.findall(r'HTTP/\d(?:\.\d)?"\s+401\b', evidence_text)) >= 5
        ):
            hits.append("At least five HTTP 401 responses")
        if hits:
            matches.append(
                {"label": label, "mitre": mitre, "severity": severity, "evidence": hits}
            )
    primary = (
        matches[0]
        if matches
        else {"label": "unknown", "mitre": [], "severity": "medium", "evidence": []}
    )
    supplied_severity = next(
        (
            v.lower()
            for k, v in safe_fields.items()
            if k.lower() in ("severity", "alert.severity", "event.severity")
        ),
        "",
    )
    levels = ["low", "medium", "high", "critical"]
    severity = max(
        [primary["severity"]]
        + ([supplied_severity] if supplied_severity in levels else []),
        key=levels.index,
    )
    iocs, seen = [], set()

    def add(kind, value, field, internal=None):
        key = (kind, value)
        if key not in seen and len(iocs) < 250:
            seen.add(key)
            iocs.append(
                {
                    "type": kind,
                    "value": value,
                    "source_field": field,
                    "is_internal": internal,
                    "display": (
                        value.replace("http", "hxxp").replace(".", "[.]")
                        if kind in ("url", "domain", "email", "ip")
                        else value
                    ),
                }
            )

    for field, value in safe_fields.items():
        value = (
            value.replace("[.]", ".")
            .replace("hxxps://", "https://")
            .replace("hxxp://", "http://")
        )
        for candidate in re.findall(
            r"(?<![\w.])(?:\d{1,3}\.){3}\d{1,3}(?![\w.])|(?<![\w:])[\da-fA-F]*:[\da-fA-F:]+(?:%\w+)?",
            value,
        ):
            try:
                ip = ipaddress.ip_address(candidate)
                add("ip", str(ip), field, ip.is_private)
            except ValueError:
                pass
        for cve in re.findall(r"\bCVE-\d{4}-\d{4,}\b", value, re.I):
            add("cve", cve.upper(), field)
        for digest in re.findall(
            r"\b(?:[a-fA-F0-9]{64}|[a-fA-F0-9]{40}|[a-fA-F0-9]{32})\b", value
        ):
            add(
                {32: "md5", 40: "sha1", 64: "sha256"}[len(digest)],
                digest.lower(),
                field,
            )
        for email in re.findall(r"\b[\w.+-]+@[\w.-]+\.[a-zA-Z]{2,}\b", value):
            add("email", email.lower(), field)
        for url in re.findall(r'https?://[^\s<>"\']+', value):
            add("url", url.rstrip(".,);"), field)
            host = urlsplit(url).hostname
            if host:
                add("domain", host.lower(), field)
        if re.search(r"(?:domain|hostname|host|server)$", field, re.I):
            if re.fullmatch(r"(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}", value):
                add("domain", value.lower(), field)
        for host in re.findall(r'(?:server: |host: ")([\w.-]+\.[a-zA-Z]{2,})', value):
            add("domain", host.lower(), field)
        for resource in re.findall(r"(?:s3://|arn:aws:s3:::)[\w./-]+", value):
            add("cloud_resource", resource, field)
    observed = next(
        (
            v
            for k, v in safe_fields.items()
            if k in ("timestamp", "@timestamp", "event.timestamp", "time")
        ),
        None,
    )
    return {
        "classification": {
            "primary": primary["label"],
            "secondary": [m["label"] for m in matches[1:]],
            "confidence": 0.9 if matches else 0.0,
            "confidence_kind": "rule heuristic, not calibrated probability",
            "evidence": primary["evidence"],
            "mitre": primary["mitre"],
        },
        "severity": severity,
        "iocs": iocs,
        "warnings": warnings,
        "observed_at": observed,
        "raw": redact(json.dumps(raw, indent=2) if not isinstance(raw, str) else raw),
        "products": [p for p in ("nginx-ui", "nginx", "php") if p in lower],
    }
