"""Structure-aware local indexing and hybrid lexical/vector retrieval."""

from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re
import threading

import chromadb
from chromadb.config import Settings
from sklearn.feature_extraction.text import HashingVectorizer

PLAYBOOK_MAP = {
    "phishing": "phishing-response",
    "ransomware": "ransomware-response",
    "brute_force": "brute-force-response",
    "credential_stuffing": "brute-force-response",
    "malware": "malware-response",
    "suspicious_login": "suspicious-login-response",
}


def tokenize(text):
    return re.findall(r"[a-z0-9]+", text.lower())


class Knowledge:
    def __init__(self, root: Path, storage: Path):
        self.root = root
        self.lock = threading.RLock()
        self.encoder = HashingVectorizer(
            n_features=384, alternate_sign=False, norm="l2", ngram_range=(1, 2)
        )
        self.client = chromadb.PersistentClient(
            path=str(storage / "chroma"), settings=Settings(anonymized_telemetry=False)
        )
        self.collection = self.client.get_or_create_collection(
            "soc_knowledge_v1",
            metadata={"hnsw:space": "cosine"},
            embedding_function=None,
        )
        self.ingest()

    def ingest(self):
        with self.lock:
            return self._ingest()

    def _ingest(self):
        chunks = []
        for path in sorted(self.root.glob("**/playbooks/*.md")):
            content = path.read_text()
            version = hashlib.sha256(content.encode()).hexdigest()
            lines = content.splitlines()
            title = lines[0].lstrip("# ")
            phase = ""
            for number, line in enumerate(lines, 1):
                heading = re.match(r"^##\s+(?:\d+\.\s+)?(.+)", line)
                if heading:
                    phase = heading[1].strip().lower()
                step = re.match(r"^\d+\.\s+(.+)", line)
                if step and phase in (
                    "investigation",
                    "containment",
                    "eradication",
                    "recovery",
                ):
                    chunks.append(
                        {
                            "id": f"{path.stem}@{version[:12]}:L{number}",
                            "kind": "sop",
                            "title": title,
                            "playbook": path.stem,
                            "phase": phase,
                            "text": step[1],
                            "source": str(path.relative_to(self.root)),
                            "version": version,
                            "line_start": number,
                            "line_end": number,
                            "source_line": line,
                            "source_snapshot": content,
                        }
                    )
        for path in sorted(self.root.glob("**/*.json")):
            doc = json.loads(path.read_text())
            if "cveMetadata" not in doc:
                continue
            cna = doc.get("containers", {}).get("cna", {})
            summary = next(
                (
                    d["value"]
                    for d in cna.get("descriptions", [])
                    if d.get("lang") == "en"
                ),
                "",
            )
            metrics = cna.get("metrics", [])
            cvss = next(
                (
                    v.get("baseScore")
                    for m in metrics
                    for k, v in m.items()
                    if k.startswith("cvss")
                ),
                None,
            )
            cve_id = doc["cveMetadata"]["cveId"]
            chunks.append(
                {
                    "id": cve_id,
                    "kind": "cve",
                    "title": cve_id,
                    "text": summary,
                    "source": str(path.relative_to(self.root)),
                    "cvss": cvss,
                    "affected": cna.get("affected", []),
                    "references": [
                        r["url"]
                        for r in cna.get("references", [])
                        if r.get("url", "").startswith("https://")
                    ],
                    "updated": doc["cveMetadata"].get("dateUpdated"),
                    "version": hashlib.sha256(path.read_bytes()).hexdigest(),
                }
            )
        if not chunks:
            raise RuntimeError("No supported knowledge documents found.")
        self.chunks = {c["id"]: c for c in chunks}
        texts = [
            f"{c['title']} {c.get('phase','')} {c['text']} {json.dumps(c.get('affected', []))}"
            for c in chunks
        ]
        vectors = self.encoder.transform(texts).toarray().tolist()
        self.collection.upsert(
            ids=[c["id"] for c in chunks],
            embeddings=vectors,
            documents=texts,
            metadatas=[
                {"kind": c["kind"], "playbook": c.get("playbook", "")} for c in chunks
            ],
        )
        stale = set(self.collection.get()["ids"]) - self.chunks.keys()
        if stale:
            self.collection.delete(ids=list(stale))
        self.tokens = {c["id"]: Counter(tokenize(t)) for c, t in zip(chunks, texts)}
        self.df = Counter(token for counts in self.tokens.values() for token in counts)
        self.avglen = sum(sum(c.values()) for c in self.tokens.values()) / len(chunks)
        return self.stats()

    def stats(self):
        return {
            "playbooks": len(
                {c["playbook"] for c in self.chunks.values() if c["kind"] == "sop"}
            ),
            "steps": sum(c["kind"] == "sop" for c in self.chunks.values()),
            "advisories": sum(c["kind"] == "cve" for c in self.chunks.values()),
            "embedding_mode": "local 384-dimensional hashed word/ngram vectors (lexical baseline)",
            "generation_mode": "deterministic extractive fallback",
            "gaps": ["ddos", "public_s3"],
        }

    def search(self, query, kind="sop", playbook=None, limit=20):
        where = (
            {"kind": kind}
            if not playbook
            else {"$and": [{"kind": kind}, {"playbook": playbook}]}
        )
        candidates = [
            c
            for c in self.chunks.values()
            if c["kind"] == kind and (not playbook or c.get("playbook") == playbook)
        ]
        if not candidates:
            return []
        dense = self.collection.query(
            query_embeddings=self.encoder.transform([query]).toarray().tolist(),
            where=where,
            n_results=min(limit, len(candidates)),
        )["ids"][0]

        def bm25(chunk):
            counts = self.tokens[chunk["id"]]
            length = sum(counts.values())
            return sum(
                math.log(1 + (len(self.chunks) - self.df[t] + 0.5) / (self.df[t] + 0.5))
                * (counts[t] * 2.5)
                / (counts[t] + 1.5 * (0.25 + 0.75 * length / self.avglen))
                for t in tokenize(query)
                if counts[t]
            )

        sparse = [c["id"] for c in sorted(candidates, key=bm25, reverse=True)[:limit]]
        ranks = Counter()
        for ranking in (dense, sparse):
            for rank, chunk_id in enumerate(ranking):
                ranks[chunk_id] += 1 / (60 + rank + 1)
        return [
            {**self.chunks[k], "retrieval_score": round(score, 6)}
            for k, score in ranks.most_common(limit)
        ]

    def retrieve(self, parsed):
        with self.lock:
            label = parsed["classification"]["primary"]
            playbook = PLAYBOOK_MAP.get(label)
            steps = (
                self.search(
                    label.replace("_", " ") + " containment isolate block reset",
                    playbook=playbook,
                    limit=50,
                )
                if playbook
                else []
            )
            # Preserve complete procedure order, including conditional language.
            steps.sort(key=lambda c: c["line_start"])
            ids = {i["value"] for i in parsed["iocs"] if i["type"] == "cve"}
            cves = []
            for c in self.chunks.values():
                if c["kind"] != "cve":
                    continue
                products = [a.get("product", "").lower() for a in c["affected"]]
                reason = (
                    "Explicit CVE identifier in alert"
                    if c["id"] in ids
                    else "Product-name candidate; version and exposure unverified"
                )
                if c["id"] in ids or any(
                    p == product for p in parsed["products"] for product in products
                ):
                    cves.append(
                        {**c, "match_reason": reason, "exposure_confirmed": False}
                    )
            cves.sort(key=lambda c: (c["id"] in ids, c["cvss"] or 0), reverse=True)
            gaps = (
                []
                if steps
                else [
                    f'No supplied SOP covers {label.replace("_", " ")}. Escalate to Tier-2; no containment procedure generated.'
                ]
            )
            gaps += [
                f"{i} is not present in the local CVE feed."
                for i in sorted(ids - self.chunks.keys())
            ]
            return steps, cves, gaps


def checklist(chunks):
    result = []
    for c in chunks:
        # Verify exact source line and action. Stored snapshots pin evidence across re-indexes.
        line = c["source_snapshot"].splitlines()[c["line_start"] - 1]
        if line != c["source_line"] or c["text"] not in line:
            continue
        high = bool(
            re.search(
                r"\b(isolate|disable|rebuild|reset|purge|offline|restore|delete)\b",
                c["text"],
                re.I,
            )
        )
        result.append(
            {
                "id": c["id"],
                "action": c["text"],
                "phase": c["phase"],
                "status": "pending",
                "requires_approval": high,
                "approved": False,
                "risk_level": "high" if high else "medium",
                "risk_basis": "Conservative application policy; not supplied SOP metadata",
                "verified": True,
                "citation": {
                    k: c[k]
                    for k in (
                        "source",
                        "version",
                        "line_start",
                        "line_end",
                        "source_line",
                        "source_snapshot",
                    )
                },
                "retrieval_score": c["retrieval_score"],
            }
        )
    return result
