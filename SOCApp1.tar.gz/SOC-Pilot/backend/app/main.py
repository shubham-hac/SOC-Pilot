from contextlib import asynccontextmanager
import json
import os
from pathlib import Path
import time
from typing import Literal

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field

from .intelligence import parse_alert, redact
from .knowledge import Knowledge, checklist
from .store import Store, ticket

PROJECT = Path(__file__).resolve().parents[2]


class AlertInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    raw: str | dict | list = Field(
        description="Raw JSON object/array, JSON text, or NGINX log text"
    )


class EventInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    type: Literal["complete", "reopen", "approve", "note"]
    step_id: str | None = None
    note: str = Field(default="", max_length=4000)


def create_app(data_dir: Path | None = None, storage: Path | None = None):
    storage = storage or Path(os.environ.get("SOC_STORAGE", PROJECT / ".runtime"))
    data_dir = data_dir or PROJECT / "dataset"

    @asynccontextmanager
    async def lifespan(app):
        storage.mkdir(parents=True, exist_ok=True)
        app.state.knowledge = Knowledge(data_dir, storage)
        app.state.store = Store(storage / "incidents.sqlite3")
        yield

    app = FastAPI(title="SOC Pilot", version="0.1.0", lifespan=lifespan)

    @app.middleware("http")
    async def limits(request: Request, call_next):
        # Check actual bytes as Content-Length can be missing or forged.
        if request.method in ("POST", "PUT", "PATCH"):
            body = bytearray()
            async for chunk in request.stream():
                body.extend(chunk)
                if len(body) > 256_000:
                    from fastapi.responses import JSONResponse

                    return JSONResponse(
                        {"detail": "Maximum request size is 256 KB."}, status_code=413
                    )
            request._body = bytes(body)
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        return response

    def parse(payload):
        try:
            return parse_alert(payload.raw)
        except (ValueError, RecursionError) as exc:
            raise HTTPException(422, str(exc)) from exc

    def load(incident_id):
        try:
            return app.state.store.get(incident_id)
        except KeyError:
            raise HTTPException(404, "Incident not found.")

    @app.get("/v1/health")
    def health():
        return {"status": "ready", **app.state.knowledge.stats()}

    @app.post("/v1/alerts/parse")
    def parse_endpoint(payload: AlertInput):
        return parse(payload)

    @app.post("/v1/alerts/analyze")
    def analyze(payload: AlertInput, stream: bool = False):
        started = time.perf_counter()
        parsed = parse(payload)
        chunks, cves, gaps = app.state.knowledge.retrieve(parsed)
        steps = checklist(chunks)
        if chunks and not steps:
            gaps.append(
                "Source verification failed. No checklist generated; escalate to Tier-2."
            )
        incident = app.state.store.create(
            {
                "parsed": parsed,
                "checklist": steps,
                "cves": cves,
                "gaps": gaps,
                "grounding_score": 1.0 if steps else None,
                "mode": "deterministic extractive fallback",
                "latency_ms": round((time.perf_counter() - started) * 1000, 1),
            }
        )
        if not stream:
            return incident

        def events():
            yield f"event: parsed\ndata: {json.dumps(parsed)}\n\n"
            yield f'event: retrieved\ndata: {json.dumps({"cves":cves,"gaps":gaps})}\n\n'
            for step in steps:
                yield f"event: step\ndata: {json.dumps(step)}\n\n"
            yield f"event: done\ndata: {json.dumps(incident)}\n\n"

        return StreamingResponse(events(), media_type="text/event-stream")

    @app.get("/v1/incidents")
    def incidents():
        return app.state.store.list()

    @app.get("/v1/incidents/{incident_id}")
    def incident(incident_id: str):
        return load(incident_id)

    @app.post("/v1/incidents/{incident_id}/events")
    def event(incident_id: str, payload: EventInput):
        try:
            data = payload.model_dump()
            data["note"] = redact(data["note"])
            return app.state.store.event(incident_id, data)
        except KeyError:
            raise HTTPException(404, "Incident not found.")
        except ValueError as exc:
            raise HTTPException(409, str(exc))

    @app.post("/v1/incidents/{incident_id}/ticket")
    def generate_ticket(incident_id: str):
        load(incident_id)
        incident = app.state.store.event(incident_id, {"type": "ticket_generated"})
        return ticket(incident)

    @app.post("/v1/knowledge/ingest")
    def ingest():
        return app.state.knowledge.ingest()

    @app.get("/v1/knowledge/gaps")
    def gaps():
        return {
            "missing_playbooks": app.state.knowledge.stats()["gaps"],
            "provenance": "Supplied repository playbooks; organizational approval has not been independently established.",
        }

    @app.get("/v1/samples")
    def samples():
        paths = sorted((PROJECT / "samples").glob("*.json")) + sorted(
            (PROJECT / "testdata").glob("*.log")
        )
        return [
            {
                "name": p.stem.replace("_", " ").replace("-", " ").title(),
                "raw": p.read_text(),
            }
            for p in paths
        ]

    frontend = PROJECT / "frontend" / "dist"
    if frontend.exists():
        app.mount("/", StaticFiles(directory=frontend, html=True), name="frontend")
    return app


app = create_app()
